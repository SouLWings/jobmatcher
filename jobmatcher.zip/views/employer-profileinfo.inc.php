Company:<?php echo $user['name'] ?><br>
Position:<?php echo $user['position'] ?>