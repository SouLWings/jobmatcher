<?php require_account_type('jobseeker');?>
<li><a href='resume.php'> <span class="glyphicon glyphicon-file"></span> My resume</a></li>
<li><a href='jobapplications.php'> <span class="glyphicon glyphicon-export"></span> My applications</a></li>