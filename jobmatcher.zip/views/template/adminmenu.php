<?php require_account_type('admin');?>
<li><a href='manageAccounts.php'> <span class="glyphicon glyphicon-user"></span> Pending accounts</a></li>
<li><a href='manageJobs.php'> <span class="glyphicon glyphicon-briefcase"></span> Pending jobs</a></li>
<li><a href='articles.php'> <span class="glyphicon glyphicon-book"></span> Articles</a></li>
