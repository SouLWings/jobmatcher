<a href='register.php' class="pull-right btn btn-primary navbar-btn">Register</a>
<a class="pull-right btn btn-primary navbar-btn" id='signinbtn'>Sign In</a>
<div id='jobsearch' class="pull-right navbar-btn">
	<form action ='jobs.php' method = 'GET' style='width:276px;'>
		<div class="input-group">
			<input type="text" name='name' class="form-control" placeholder="Job search" required>
			<span class="input-group-btn">
				<button type="submit" class="btn btn-primary">
					<span class="glyphicon glyphicon-search"></span>
				</button>
			</span>
		</div>
		<input type='hidden' name='search'>
	</form>
</div>