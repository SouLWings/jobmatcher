<?php require_account_type('employer');?>
<li><a href='managejobads.php'> <span class="glyphicon glyphicon-briefcase"></span> My job advertisements</a></li>
<li><a href='company.php?id=<?php echo $cid?>'> <span class="glyphicon glyphicon-home"></span> My company</a></li>